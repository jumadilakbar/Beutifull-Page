<?php
mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("poltekes") or die (mysql_error());
?>
