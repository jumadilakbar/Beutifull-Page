<div class="list-group">
  <a href="?rute=beranda" class="bg-dark text-white list-group-item list-group-item-action">
    Beranda
  </a>
  <a href="?rute=rekap" class="bg-dark text-white list-group-item list-group-item-action">
    Rekap Pembayaran
  </a>
</div>
