<div class="list-group">
  <a href="?rute=beranda" class="bg-dark text-white list-group-item list-group-item-action">
    Beranda
  </a>
  <a href="?rute=registrasi" class="bg-dark text-white list-group-item list-group-item-action">Registrasi
  </a>
  <a href="?rute=poliumum" class="bg-dark text-white list-group-item list-group-item-action ">Data Pasien
  </a>
  <a href="?rute=user" class="bg-dark text-white list-group-item list-group-item-action ">Kelola User
  </a>
</div>
